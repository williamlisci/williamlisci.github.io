- không ai sinh ra đã biết tất cả mọi thứ; con người cần rất nhiều thời gian để trưởng thành và học hỏi. 段永平.
- Bạn không học cách bước đi bằng việc học thuộc các quy tắc. Bạn học bằng cách tự mình bước đi và vấp ngã
- Vào tháng 4/2025, tại một hội nghị giáo dục, GS Đỗ Đức Thái (nguyên Trưởng khoa Toán - Tin, Trường Đại học Sư phạm Hà Nội, đồng thời là Chủ biên chương trình môn Toán mới) đã chia sẻ một câu chuyện thực tế.
Ông cho biết Khoa Toán - Tin của trường có 3 giáo sư chuyên sâu về hình học phức (bao gồm cả ông). Khi thách đố nhau giải câu hỏi 44 mã đề 102 đề thi tốt nghiệp THPT môn Toán năm 2024 , các giáo sư đã mất nguyên một buổi chiều ngồi làm thử nhưng vẫn không ra kết quả.
GS Thái cho hay, trong những lần tập huấn đối với giáo viên, ông cũng thường nhắc đến chuyện “học để làm gì”. “Đó là để cuối cùng phải nuôi được bản thân, gia đình nhỏ của mình và đóng góp cho sự phát triển của xã hội”, GS Thái nói.
- mục tiêu tối thượng của việc học không phải để vượt qua các kỳ thi mà là xây dựng năng lực thực sự để hiểu, vận hành, dự đoán và kiểm soát các hệ thống trong thế giới thực. Thay vì tập trung tối ưu hóa điểm số, hãy tối ưu hóa năng lực.
