# Khái quát hóa, đặc biệt hóa và tư duy tương tự trong toán học

---

## Mở đầu: Toán học không chỉ là giải bài toán

Khi học toán, chúng ta thường chú ý đến công thức, định lý và kỹ thuật giải. Nhưng phía sau những kết quả ấy là một hệ thống tư duy sâu hơn: làm thế nào để nhận ra quy luật từ những trường hợp riêng, làm thế nào để kiểm tra một nhận định tổng quát, và làm thế nào để chuyển một ý tưởng từ lĩnh vực toán học này sang lĩnh vực khác?

Ba thao tác đặc biệt quan trọng trong quá trình đó là **khái quát hóa**, **đặc biệt hóa** và **tư duy tương tự**.

- **Khái quát hóa** giúp tìm ra cấu trúc chung ẩn sau nhiều hiện tượng.
- **Đặc biệt hóa** giúp đưa vấn đề trừu tượng về những trường hợp có thể quan sát, tính toán và kiểm tra.
- **Tư duy tương tự** giúp nhận ra sự tương đồng về cấu trúc, từ đó chuyển giao ý tưởng và hình thành phỏng đoán mới.

Chúng không phải ba kỹ năng tách biệt. Chúng liên kết thành một chu trình nhận thức: quan sát trường hợp cụ thể, phát hiện sự tương đồng, đề xuất quy luật tổng quát, kiểm tra quy luật bằng các trường hợp đặc biệt, rồi tiếp tục mở rộng hiểu biết.

Mục tiêu của tư duy toán học không phải chỉ là tìm được đáp số của một bài toán, mà còn là hiểu **vì sao phương pháp ấy đúng, điều kiện nào khiến nó đúng, và nó còn đúng trong những hoàn cảnh nào khác**.

---

## 1. Khái quát hóa: Tìm cấu trúc chung đằng sau những trường hợp riêng

### 1.1. Bản chất của khái quát hóa

**Khái quát hóa (Generalization)** là quá trình đi từ một hoặc nhiều trường hợp cụ thể đến một nhận định có phạm vi áp dụng rộng hơn. Điều quan trọng không phải là mở rộng một cách tùy tiện, mà là nhận ra yếu tố nào thực sự quyết định kết quả và có thể được giữ lại khi thay đổi đối tượng.

Quá trình này thường bao gồm những thao tác sau:

1. **Mở rộng miền đối tượng:** Chẳng hạn, từ số tự nhiên $\mathbb{N}$ đến số nguyên $\mathbb{Z}$, số hữu tỉ $\mathbb{Q}$, số thực $\mathbb{R}$ rồi số phức $\mathbb{C}$; từ tam giác đến đa giác; từ không gian Euclid $\mathbb{R}^n$ đến những không gian Hilbert/Banach trừu tượng hơn.
2. **Loại bỏ điều kiện không cốt yếu:** Xác định giả thiết nào chỉ xuất hiện do cách đặt bài toán, giả thiết nào thật sự cần thiết cho kết luận.
3. **Trừu tượng hóa cấu trúc:** Thay những đối tượng cụ thể bằng các khái niệm mô tả quan hệ chung. Ví dụ, thay phép cộng số thực cụ thể bằng một phép toán hai ngôi trừu tượng thỏa mãn các tiên đề của nhóm (Group).
4. **Phát hiện quy luật:** Quan sát nhiều trường hợp, nhận ra mẫu hình và đề xuất một mệnh đề tổng quát.
5. **Đưa hằng số thành tham số:** Từ một phương trình cụ thể như $x^2-2=0$, xét cả họ phương trình $x^2-a=0$, qua đó tìm hiểu nghiệm thay đổi thế nào theo tham số $a$.

Có thể hình dung khái quát hóa như việc chuyển từ nhìn từng cái cây sang nhận diện cấu trúc của cả khu rừng. Người giải không còn chỉ ghi nhớ từng kết quả, mà tìm cách giải thích vì sao nhiều kết quả cùng xuất hiện.

### 1.2. Khái quát hóa khác trừu tượng hóa như thế nào?

Hai khái niệm có liên hệ chặt chẽ nhưng không đồng nhất.

- **Khái quát hóa** chủ yếu mở rộng phạm vi đối tượng hoặc phạm vi áp dụng của một nhận định (mở rộng về chiều rộng).
- **Trừu tượng hóa (Abstraction)** chủ yếu loại bỏ những đặc điểm cụ thể để giữ lại các quan hệ và cấu trúc cốt lõi (đi sâu vào chiều bản chất).

Ví dụ, xét từ tam giác vuông đến tam giác bất kỳ là một hướng mở rộng đối tượng (khái quát hóa). Trong khi đó, chuyển từ phép cộng các số cụ thể sang khái niệm phép toán nhóm là một bước trừu tượng hóa: ta không còn quan tâm phép toán được biểu diễn bằng ký hiệu nào hay tính toán trên số nào, mà quan tâm đến các tiên đề (kết hợp, phần tử trung hòa, phần tử nghịch đảo) mà nó thỏa mãn.

Trong thực tế, hai thao tác thường phối hợp. Ta có thể mở rộng một cấu trúc trước, rồi tiếp tục trừu tượng hóa để nhận ra nguyên lý sâu hơn.

### 1.3. Vì sao một bài toán tổng quát đôi khi dễ hơn bài toán riêng?

Một ý tưởng đáng chú ý trong phương pháp giải toán của George Pólya là **Nghịch lý Nhà phát minh (Inventor's Paradox)**: đôi khi muốn giải một bài toán cụ thể, ta nên giải một bài toán rộng hơn.

Điều này nghe có vẻ ngược đời. Thông thường, bài toán càng tổng quát càng khó. Nhưng một phát biểu tổng quát có thể bộc lộ cấu trúc, quy luật hoặc phép quy nạp mà trường hợp riêng che khuất.

Ví dụ, thay vì tìm cách chứng minh một kết quả chỉ đúng tại một giá trị $n$ cụ thể (như $n=100$), ta chứng minh công thức cho mọi số tự nhiên $n$ bằng quy nạp. Việc có giả thiết quy nạp cho $k$ giúp ta chứng minh cho $k+1$ dễ dàng hơn nhiều so với việc chứng minh trực tiếp trường hợp $n=100$. Khi đã có định lý tổng quát, trường hợp riêng chỉ còn là phép thế giá trị.

Bài học ở đây là: **đừng mặc định rằng thu hẹp bài toán luôn làm nó dễ hơn**. Đôi khi mở rộng đúng hướng lại giúp ta nhìn thấy công cụ giải quyết.

### 1.4. Sức mạnh thống nhất của khái quát hóa

Một trong những giá trị lớn nhất của khái quát hóa là khả năng thống nhất những kiến thức tưởng như rời rạc.

Chẳng hạn, định lý Pythagore và định lý Cosin có thể được nhìn dưới góc độ tích vô hướng trong không gian Euclid (hoặc không gian Hilbert): Với hai vectơ $u, v$, ta có:

$$\|u-v\|^2 = \|u\|^2 + \|v\|^2 - 2\langle u, v\rangle$$

Khi hai vectơ vuông góc, tích vô hướng $\langle u,v\rangle = 0$ và biểu thức trở thành dạng của định lý Pythagore. Khi góc giữa chúng là $C$, với $\langle u,v\rangle = \|u\| \|v\| \cos C$, ta thu được quan hệ tương ứng với định lý Cosin.

Như vậy, thay vì ghi nhớ hai công thức riêng, người học có thể hiểu chúng như những biểu hiện của một cấu trúc chung về độ dài, góc và tích vô hướng.

Một ví dụ khác là chuỗi khái quát hóa trong đại số số học:

- **Định lý nhỏ Fermat:** Xét trường hợp môđun là số nguyên tố $p$.
- **Định lý Euler:** Mở rộng kết quả sang các môđun $n$ bất kỳ khi số $a$ nguyên tố cùng nhau với $n$ (sử dụng hàm phi Euler $\phi(n)$).
- **Định lý Lagrange:** Đặt một kết quả về bậc phần tử vào khuôn khổ lý thuyết nhóm hữu hạn (bậc của nhóm con chia hết bậc của nhóm).

Các kết quả này không chỉ mở rộng phạm vi áp dụng. Chúng còn giúp nhận ra cơ chế đại số đứng phía sau những hiện tượng số học.

### 1.5. Cái giá của khái quát hóa: Có thể mở rộng đối tượng nhưng mất tính chất

Khái quát hóa không phải lúc nào cũng bảo toàn mọi đặc điểm của trường hợp ban đầu. Khi mở rộng miền đối tượng, ta có thể phải từ bỏ một số tính chất quen thuộc.

Ví dụ:

- **Từ số thực $\mathbb{R}$ sang số phức $\mathbb{C}$:** Ta có được tính đóng đại số (mọi đa thức không hằng với hệ số phức đều có nghiệm phức theo Định lý cơ bản của đại số). Tuy nhiên, ta mất đi tính thứ tự: không thể định nghĩa một quan hệ thứ tự toàn phần trên $\mathbb{C}$ tương thích với các phép toán trường như trên $\mathbb{R}$.
- **Từ không gian hữu hạn chiều sang không gian vô hạn chiều:** Nhiều tính chất compact quen thuộc (như định lý Heine-Borel) không còn đúng với hình cầu đơn vị đóng trong chuẩn thông thường (Định lý Riesz).
- **Từ hàm khả vi sang lớp hàm liên tục:** Miền đối tượng rộng hơn nhưng ta không còn được quyền sử dụng công cụ đạo hàm cho mọi hàm.

Vì vậy, mỗi lần khái quát hóa cần đặt hai câu hỏi:

1. Những tính chất nào được giữ lại?
2. Những tính chất nào bị mất đi, và cần bổ sung giả thiết gì để khôi phục kết luận?

Đây là lý do các định lý trong giải tích thường cần những điều kiện như hội tụ đều, tính compact hoặc tính lồi. Những giả thiết ấy không phải chi tiết trang trí; chúng bù đắp cho các tính chất đã mất khi mở rộng phạm vi.

---

## 2. Đặc biệt hóa: Đi sâu vào trường hợp cụ thể để hiểu và kiểm chứng

### 2.1. Bản chất của đặc biệt hóa

**Đặc biệt hóa (Specialization)** là quá trình thu hẹp một vấn đề tổng quát bằng cách chọn trường hợp cụ thể, thêm điều kiện hoặc cố định một số tham số.

Nếu khái quát hóa mở rộng phạm vi quan sát, đặc biệt hóa đưa ta đến gần một trường hợp đủ rõ để có thể hình dung, tính toán hoặc kiểm tra.

Các cách đặc biệt hóa thường gặp gồm:

- Chọn giá trị cụ thể cho tham số (ví dụ: cho $a=0, b=1, n=2$).
- Xét trường hợp nhỏ nhất hoặc đơn giản nhất ($n=1$, $n=2$).
- Thêm điều kiện đặc biệt (như tam giác đều, ma trận đối xứng, hàm liên tục trên đoạn đóng).
- Xét trường hợp biên và trường hợp suy biến (tọa độ bằng 0, định thức bằng 0, tam giác bẹt).
- Chuyển vấn đề trừu tượng về một mô hình quen thuộc hơn (như mô hình hình học phẳng).

Đặc biệt hóa không chỉ phục vụ minh họa. Nó là một công cụ khám phá và kiểm tra có giá trị thực chất.

### 2.2. Thử những trường hợp nhỏ để nhìn thấy quy luật

Khi gặp một dãy số hoặc một công thức phụ thuộc vào $n$, ta có thể thử các giá trị đầu như $n=1, 2, 3, 4$.

Việc tính toán một số trường hợp không chứng minh được mệnh đề đúng với mọi $n$, nhưng có thể giúp:

- Nhận ra mẫu hình (pattern recognition).
- Đoán công thức tổng quát.
- Phát hiện trường hợp ngoại lệ.
- Xác định hướng chứng minh phù hợp (ví dụ lựa chọn quy nạp hay biến đổi đại số).

Ví dụ, nếu cần tìm công thức tổng $S_n = 1+2+\cdots+n$, ta có thể tính một vài giá trị đầu: $S_1=1, S_2=3, S_3=6, S_4=10$. Qua đó quan sát tỉ lệ $\frac{S_n}{n}$ và dự đoán công thức:

$$1+2+\cdots+n = \frac{n(n+1)}{2}$$

Sau đó, ta mới chứng minh công thức bằng quy nạp toán học hoặc lập luận ghép cặp của Gauss. Các trường hợp nhỏ tạo ra phỏng đoán; chứng minh mới xác lập kết quả.

### 2.3. Trường hợp biên và suy biến: Phép thử rất mạnh

Một mệnh đề có vẻ đúng trong những trường hợp thông thường vẫn có thể thất bại ở biên.

Vì vậy, người giải cần tập thói quen kiểm tra:

- Giá trị nhỏ nhất hoặc lớn nhất được phép.
- Tham số bằng $0$ hoặc âm.
- Mẫu số tiến tới $0$ hoặc biểu thức tiến tới vô cùng.
- Hai điểm trùng nhau hoặc ba điểm thẳng hàng.
- Ma trận có định thức bằng $0$ (ma trận suy biến).
- Hình hình học tiến đến cấu hình suy biến (ví dụ: tam giác suy biến thành một đoạn thẳng khi độ dài một cạnh bằng tổng hai cạnh còn lại).

Chẳng hạn, công thức diện tích Heron $S = \sqrt{p(p-a)(p-b)(p-c)}$ cho $S = 0$ khi $a + b = c$ (ba đỉnh thẳng hàng, tam giác suy biến thành đoạn thẳng). Điều này khớp hoàn toàn với thực tế hình học.

Các trường hợp biên có giá trị bởi chúng làm lộ ra những điều kiện ẩn mà trường hợp thông thường có thể che giấu.

### 2.4. Đặc biệt hóa để tìm phản ví dụ

Đặc biệt hóa là công cụ tối quan trọng để bác bỏ một phỏng đoán sai.

Giả sử ai đó khẳng định: *“Mọi đa thức với hệ số thực đều phân tích được thành tích các đa thức bậc nhất với hệ số thực.”*

Chỉ cần xét trường hợp cụ thể với đa thức:

$$P(x) = x^2 + 1$$

Ta thấy $P(x) > 0$ với mọi $x \in \mathbb{R}$, do đó nó không có nghiệm thực và không thể phân tích thành tích hai nhân tử bậc nhất hệ số thực.

Mệnh đề tổng quát đã bị bác bỏ hoàn toàn chỉ bằng một trường hợp cụ thể này.

Điều này phản ánh nguyên lý logic cơ bản:

- Muốn chứng minh một mệnh đề phổ quát ($\forall x, P(x)$), cần một lập luận bao quát mọi trường hợp trong miền xét.
- Muốn bác bỏ mệnh đề phổ quát, chỉ cần chỉ ra **một phản ví dụ** ($\exists x, \neg P(x)$).

Do đó, khi kiểm tra một phỏng đoán, ta không nên chỉ tìm những ví dụ xác nhận nó (confirmation bias). Ta cần chủ động thử các trường hợp khắc nghiệt nhất để tìm phản ví dụ.

### 2.5. Không mất tính tổng quát (WLOG)

Kỹ thuật **Without Loss of Generality (WLOG - Không mất tính tổng quát)** cho phép ta chỉ xét một trường hợp đại diện khi có thể chứng minh rằng các trường hợp còn lại hoàn toàn tương đương với nó qua một phép đối xứng hoặc biến đổi thích hợp.

Ví dụ, nếu một bất đẳng thức hoàn toàn đối xứng đối với hai biến $a, b$, ta có thể giả sử $a \ge b$. Khi đó, thay vì phải xét hai trường hợp $a \ge b$ và $a < b$, ta chỉ cần giải một nửa miền trường hợp.

Nhưng WLOG không phải giấy phép tùy ý loại bỏ trường hợp. Người giải phải đảm bảo và giải thích rõ vì sao việc giả định đó không làm giảm đi phạm vi của bài toán ban đầu. Lạm dụng WLOG khi đối tượng thiếu tính đối xứng là một sai lầm phổ biến.

### 2.6. Tư tưởng Pólya: Giải một bài toán dễ hơn trước

Trong tác phẩm kinh điển *How to Solve It* (1945), George Pólya nhấn mạnh chiến lược: khi chưa giải được bài toán ban đầu, hãy tìm và giải một bài toán có liên quan nhưng dễ hơn.

Đặc biệt hóa là một cách thực hiện chiến lược ấy:

- Bỏ bớt một điều kiện phức tạp.
- Xét bài toán ở số chiều thấp hơn (ví dụ: giải bài toán trong hình học phẳng trước khi lên không gian 3D).
- Cố định một vài biến số làm hằng số.

Mục đích không phải dừng lại ở bài toán dễ, mà là **rút ra tia sáng ý tưởng** từ bài toán dễ đó để áp dụng ngược lại cho bài toán gốc.

---

## 3. Tư duy tương tự: Cây cầu nối những cấu trúc toán học

### 3.1. Tương tự là gì?

**Tư duy tương tự (Analogy)** là quá trình nhận ra hai đối tượng hoặc hai hệ thống có một số quan hệ tương đồng về mặt cấu trúc, từ đó dự đoán rằng chúng có thể chia sẻ thêm những tính chất hoặc phương pháp giải quyết khác.

Tương tự không đòi hỏi hai đối tượng giống nhau về hình thức bề ngoài. Điều cốt lõi là chúng tương đồng ở **mô hình quan hệ (relational structure)**.

Một số hướng liên hệ tương tự kinh điển trong toán học:

| Lĩnh vực A | Lĩnh vực B tương tự | Cấu trúc nối liền |
|---|---|---|
| Tổng hữu hạn $\sum$ | Tích phân $\int$ | Đại lượng tích lũy |
| Dãy số $a_n$ | Chuỗi hàm / Hàm số $f(x)$ | Rời rạc vs. Liên tục |
| Hình học phẳng (2D) | Hình học không gian (3D) | Số chiều không gian |
| Số nguyên $\mathbb{Z}$ | Đa thức $\mathbb{K}[X]$ | Miền nguyên, phép chia có dư |
| Không gian $\mathbb{R}^n$ | Không gian Hilbert $L^2$ | Tích vô hướng, độ dài, góc |

Tương tự giúp người học không phải "tái tạo lại bánh xe bò" mỗi khi sang một miền kiến thức mới. Họ dùng mô hình cũ như một bản đồ định hướng để khám phá miền đất mới.

### 3.2. Tương tự tạo ra phỏng đoán, không tạo ra chứng minh

Đây là ranh giới quan trọng nhất cần lưu ý.

Hai đối tượng tương tự nhau ở 9 tính chất không có nghĩa là tính chất thứ 10 của đối tượng này cũng đúng cho đối tượng kia.

**Ví dụ về sự sụp đổ của tư duy tương tự:**

- *Trong tổng hữu hạn:* Tổng các hàm liên tục luôn là một hàm liên tục.
- *Tương tự sang chuỗi vô hạn:* Phỏng đoán rằng tổng của một chuỗi vô hạn các hàm liên tục cũng là một hàm liên tục.

Phỏng đoán này **sai** nếu chuỗi chỉ hội tụ điểm (pointwise convergence). Phản ví dụ kinh điển là chuỗi Fourier của hàm bước nhảy. Muốn tính chất liên tục được bảo toàn qua giới hạn vô hạn, ta bắt buộc phải nâng cấp điều kiện lên **hội tụ đều (uniform convergence)**.

Ví dụ này cho thấy: Tương tự gợi mở con đường, nhưng tính chặt chẽ của toán học mới quyết định con đường đó có đi tiếp được hay không.

### 3.3. Đánh giá độ sâu của một phép tương tự

Không phải sự tương tự nào cũng mang giá trị toán học sâu sắc.

- **Tương tự bề ngoài (Nông):** Chỉ giống nhau về ký hiệu, tên gọi hoặc hình vẽ (dễ dẫn đến phỏng đoán ngây thơ).
- **Tương tự cấu trúc (Sâu):** Giống nhau về đồng hình (isomorphism), đẳng cấu, các đại lượng bất biến hoặc hệ tiên đề nền tảng.

Khi sử dụng tư duy tương tự, hãy luôn tự vấn: *Hai đối tượng này thực sự giống nhau ở cơ chế logic nào, và ranh giới mà phép tương tự này dừng lại nằm ở đâu?*

---

## 4. Mối quan hệ biện chứng: Chu trình tư duy lặp

Khái quát hóa, đặc biệt hóa và tư duy tương tự không hoạt động độc lập. Chúng đan xen tạo thành một chu trình nhận thức liên tục trong quá trình sáng tạo và học tập toán học.

```
       ┌─────────────────────────────────────────┐
       │             Quan sát Ví dụ              │
       └────────────────────┬────────────────────┘
                            │
                            ▼
       ┌──────────────────────────────────────────┐
       │   Tư duy Tương tự & Tìm quy luật     	│
       └────────────────────┬─────────────────────┘
                            │
                            ▼
       ┌─────────────────────────────────────────┐
       │      Đề xuất Phỏng đoán Tổng quát       │
       └────────────────────┬────────────────────┘
                            │
                            ▼
       ┌─────────────────────────────────────────┐
       │   Khái quát hóa cấu trúc & Đặt định lý  │
       └────────────────────┬────────────────────┘
                            │
                            ▼
       ┌────────────────────────────────────────────┐
       │  Chứng minh chặt chẽ / Bác bỏ (Phản ví dụ) │
       └────────────────────┬───────────────────────┘
                            │
                            ▼
       ┌─────────────────────────────────────────┐
       │  Đặc biệt hóa để kiểm tra & Vận dụng    │
       └────────────────────┬────────────────────┘
                            │
                            ▼
       ┌─────────────────────────────────────────┐
       │   Nêu bài toán mới ở tầm cao hơn        │
       └─────────────────────────────────────────┘
```

### 4.1. Quy nạp không đầy đủ vs. Quy nạp toán học

Cần phân biệt rõ hai khái niệm:

- **Quy nạp không đầy đủ (Empirical Induction):** Quan sát trường hợp $n=1, 2, 3...$, thấy đúng và kết luận đúng cho mọi $n$. Đây là công cụ của *phỏng đoán*, không có giá trị chứng minh trong toán học.
- **Quy nạp toán học (Mathematical Induction):** Một phương pháp suy luận diễn dịch chặt chẽ dựa trên hệ tiên đề Peano để chứng minh mệnh đề đúng cho vô hạn số tự nhiên qua hai bước (Cơ sở và Bước quy nạp).

Khái quát hóa bắt đầu từ quy nạp không đầy đủ để tìm ý tưởng, nhưng bắt buộc phải hoàn thành bằng quy nạp toán học hoặc các phương pháp chứng minh chặt chẽ khác.

### 4.2. Phân biệt đặc biệt hóa với biến đổi tương đương

Một điểm rất dễ nhầm lẫn trong giải toán:

- **Đặc biệt hóa:** Chuyển từ bài toán $P(x)$ trên miền $D$ sang xét bài toán trên miền $D' \subset D$ (hẹp hơn). Ta nhận được thông tin của một phần bài toán.
- **Biến đổi tương đương / Đổi biến:** Chuyển bài toán $P(x)$ thành bài toán $Q(y)$ qua một song ánh (bijection). Phạm vi bài toán không bị thu hẹp; giải được $Q(y)$ nghĩa là giải xong hoàn toàn $P(x)$.

Phân biệt rõ hai thao tác giúp người học tránh nhầm lẫn giữa việc "thử một trường hợp" và việc "giải bài toán".

---

## 5. Minh họa lịch sử: Những bước ngoặt nhờ chuyển đổi tư duy

### 5.1. Hình học giải tích của Descartes và Fermat

Trước thế kỷ 17, Hình học và Đại số là hai đại dương riêng biệt. 

René Descartes và Pierre de Fermat đã dùng **tư duy tương tự và khái quát hóa** để nối liền hai lĩnh vực: Mỗi điểm trên mặt phẳng tương ứng với một cặp số $(x, y)$, và mỗi đường cong tương ứng với một phương trình đại số. 

Nhờ bước khái quát hóa này, các bài toán hình học phức tạp được chuyển hóa thành các phép tính đại số hệ thống.

### 5.2. Chương trình Erlangen của Felix Klein (1872)

Vào thế kỷ 19, sự xuất hiện của hình học phi Euclid làm toán học khủng hoảng: Có quá nhiều loại hình học khác nhau (Euclid, Affine, Xạ ảnh, Lobachevsky...).

Felix Klein đã **khái quát hóa** toàn bộ hình học bằng Lý thuyết Nhóm. Ông định nghĩa: *Một nền hình học là sự nghiên cứu các tính chất bất biến của các đối tượng qua một nhóm phép biến đổi nhất định.*

- Hình học Euclid nghiên cứu các tính chất bất biến qua nhóm chuyển động dời hình (độ dài, góc).
- Hình học Affine nghiên cứu các tính chất bất biến qua phép biến đổi affine (tính song song, tỉ số độ dài trên cùng đường thẳng).
- Hình học Xạ ảnh nghiên cứu các tính chất bất biến qua phép chiếu xạ ảnh (tỉ số kép).

Chương trình Erlangen đã đưa hàng loạt môn hình học rời rạc về một đại gia đình thống nhất.

### 5.3. Lý thuyết Galois: Khái quát hóa vấn đề nghiệm phương trình

Các nhà toán học đã tìm ra công thức nghiệm cho phương trình bậc 2, bậc 3 và bậc 4, nhưng bế tắc ở bậc 5.

Évariste Galois đã không tìm công thức nghiệm trực tiếp nữa (bài toán riêng). Ông **trừu tượng hóa và khái quát hóa** vấn đề: Nghiên cứu cấu trúc nhóm đối xứng của các nghiệm (Nhóm Galois) và sự tương ứng giữa các trường con.

Kết quả: Galois chứng minh rằng phương trình bậc 5 tổng quát không thể giải được bằng căn thức vì nhóm đối xứng $S_5$ của nó không phải là một nhóm giải được (solvable group). Một câu hỏi đại số cụ thể đã khai sinh ra Lý thuyết Nhóm hiện đại.

---

## 6. Ứng dụng thực tiễn vào phương pháp học và giải toán

### 6.1. Khung câu hỏi rèn luyện tư duy (Problem-Posing Framework)

Khi học một định lý hoặc làm xong một bài tập, đừng vội gấp sách lại. Hãy tự đặt các câu hỏi theo 3 hướng:

```
                      ┌──────────────────────────┐
                      │    BÀI TOÁN BAN ĐẦU      │
                      └────────────┬─────────────┘
                                   │
         ┌─────────────────────────┼─────────────────────────┐
         ▼                         ▼                         ▼
┌───────────────────┐    ┌───────────────────┐    ┌───────────────────┐
│   ĐẶC BIỆT HÓA    │    │   KHÁI QUÁT HÓA   │    │  TƯ DUY TƯƠNG TỰ  │
├───────────────────┤    ├───────────────────┤    ├───────────────────┤
│• Trường hợp n=1?  │    │• Thay hằng số     │    │• Có giống bài toán│
│• Biên/Suy biến    │    │  thành tham số?   │    │  nào ở Đại số/    │
│  thế nào?         │    │• Mở rộng số chiều?│    │  Hình học không?  │
│• Phản ví dụ nằm   │    │• Bỏ giả thiết nào │    │• Cấu trúc bất biến│
│  ở đâu?           │    │  mà vẫn đúng?     │    │  là gì?           │
└───────────────────┘    └───────────────────┘    └───────────────────┘
```

### 6.2. Tránh hai cực đoan phổ biến

1. **Cực đoan 1: Khái quát hóa vội vàng (Over-generalization)**
   - *Biểu hiện:* Thử $n=1, 2, 3$ thấy đúng liền phán đoán đúng cho mọi $n$.
   - *Bài học cảnh tỉnh:* Đa thức Euler $f(n) = n^2 + n + 41$ cho số nguyên tố với mọi $n = 0, 1, 2, ..., 39$. Nhưng tại $n=40$:
     $$f(40) = 40^2 + 40 + 41 = 40(40+1) + 41 = 41^2 = 1681$$
     đây là hợp số! Mọi số lượng ví dụ hữu hạn đều không thay thế được chứng minh.

2. **Cực đoan 2: Đặc biệt hóa mù quáng (Over-specialization)**
   - *Biểu hiện:* Chỉ biết làm từng bài toán cụ thể, thay số là chịu, không nhận ra bài toán mới thực chất là bài toán cũ đổi vỏ bọc.
   - *Hậu quả:* Nắm giữ hàng trăm công thức mẹo nhưng không hiểu bản chất cấu trúc.

---

## Kết luận: Từ biết cách giải đến biết cách tư duy

Khái quát hóa, đặc biệt hóa và tư duy tương tự là ba chân kiềng của tư duy toán học hiện đại.

- **Khái quát hóa** mang lại **tầm nhìn rộng** và **tính hệ thống**.
- **Đặc biệt hóa** mang lại **trực giác nhạy bén** và **tính thực chứng**.
- **Tư duy tương tự** mang lại **sức sáng tạo** và **khả năng kết nối**.

Người học toán giỏi không phải là người ghi nhớ nhiều bài giải mẫu, mà là người biết luân chuyển nhuần nhuyễn giữa ba thao tác này: **dùng đặc biệt hóa để tìm manh mối, dùng tương tự để mở đường, dùng khái quát hóa để nâng tầm lý thuyết, và dùng logic chặt chẽ để hoàn thành chứng minh.**

$$\boxed{
\text{Cụ thể} 
\xrightarrow{\text{Tương tự}} 
\text{Phỏng đoán} 
\xrightarrow{\text{Khái quát hóa}} 
\text{Cấu trúc} 
\xrightarrow{\text{Chứng minh}} 
\text{Định lý} 
\xrightarrow{\text{Đặc biệt hóa}} 
\text{Ứng dụng}
}$$

Đó chính là hành trình biến việc giải toán từ một bài tập kỹ thuật thành một nghệ thuật tư duy.
